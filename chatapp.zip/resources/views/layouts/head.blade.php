    @yield('css')

    <!-- App css -->
    <link href="{{ URL::asset('assets/css/bootstrap-dark.min.css')}}" id="bootstrap-dark-style" rel="stylesheet" type="text/css" disabled="disabled" />
    <link href="{{ URL::asset('assets/css/bootstrap.min.css')}}" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link href="{{ URL::asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{ URL::asset('assets/css/app-dark.min.css')}}" id="app-dark-style" rel="stylesheet" type="text/css" disabled="disabled" />
    <link href="{{ URL::asset('assets/css/app.min.css')}}" id="app-style" rel="stylesheet" type="text/css"  />
    <link href="{{ URL::asset('vendor/emoji-picker/lib/css/emoji.css')}}" rel="stylesheet">
