<!-- JAVASCRIPT -->
<script src="<?php echo e(URL::asset('/assets/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/assets/libs/node-waves/node-waves.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/js/app.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/vendor/emoji-picker/lib/js/config.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/vendor/emoji-picker/lib/js/util.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/vendor/emoji-picker/lib/js/jquery.emojiarea.js')); ?>"></script>
<script src="<?php echo e(URL::asset('/vendor/emoji-picker/lib/js/emoji-picker.js')); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>
<!-- App js -->

<!-- Magnific Popup-->
<script src="<?php echo e(URL::asset('assets/libs/magnific-popup/magnific-popup.min.js')); ?>"></script>
<!-- owl.carousel js -->
<script src="<?php echo e(URL::asset('assets/libs/owl.carousel/owl.carousel.min.js')); ?>"></script>
<!-- page init -->
<script src="<?php echo e(URL::asset('assets/js/pages/index.init.js')); ?>"></script>

<script>
    // global app configuration object
    var my_id = "<?php echo e(Auth::id()); ?>";
    var config = {
        routes: {
            nameupdate: "<?php echo e(route('nameupdate')); ?>",
            updateavatar: "<?php echo e(route('updateavatar')); ?>",
            groups: "<?php echo e(route('groups')); ?>",
            url: "<?php echo e(URL::asset('')); ?>"
        }
    };

</script>

<?php echo $__env->yieldContent('script-bottom'); ?><?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/vendor-scripts.blade.php ENDPATH**/ ?>