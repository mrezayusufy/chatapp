    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title'); ?> | <?php echo e(__("chatapp")); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta content="Responsive Bootstrap 4 Chat App" name="description" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(URL::asset('/assets/images/favicon.ico')); ?>">
    <?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/title-meta.blade.php ENDPATH**/ ?>