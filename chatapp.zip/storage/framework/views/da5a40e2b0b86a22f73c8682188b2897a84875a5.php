<!-- Start chats content -->
<div>
    <div class="px-4 pt-4">
        <h4 class="mb-4">Chats</h4>
        <div class="search-box chat-search-box">
            <div class="input-group mb-3 bg-light  input-group-lg rounded-lg">
                <div class="input-group-prepend">
                    <button class="btn btn-link text-muted pr-1 text-decoration-none" type="button">
                        <i class="ri-search-line search-icon font-size-18"></i>
                    </button>
                </div>
                <input type="text" class="form-control bg-light" placeholder="<?php echo e(__("Search messages or users")); ?>" id="recentcontactsearch">
            </div>
            
        </div> <!-- Search Box-->
    </div> <!-- .p-4 -->
    
    <!-- Start user status -->
    <div class="px-4 pb-4" dir="ltr">

        <div class="owl-carousel owl-theme" id="user-status-carousel">
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(Cache::has('is_online' . $user->id)): ?>
                    <div class="item user chat-user-click" id="<?php echo e($user->id); ?>" user-id="<?php echo e($user->id); ?>">
                        <a href="#" class="user-status-box">
                            <div class="avatar-xs mx-auto d-block chat-user-img online">
                                <img src="<?php echo e($user->avatar); ?>" alt="user-img" class="img-fluid rounded-circle">
                                <span class="user-status"></span>
                            </div>
                            <h5 class="font-size-13 text-truncate mt-3 mb-1"><?php echo e($user->name); ?></h5>
                        </a>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- end user status carousel -->
    </div>
    <!-- end user status -->

    <!-- Start chat-message-list -->
    <div class="px-2">
        <h5 class="mb-3 px-3 font-size-16"><?php echo e(__("Recent")); ?></h5>

        <div class="chat-message-list" data-simplebar>
            <div class="chat-message-chatlist">
                <?php echo $__env->make('layouts.tabpane-recent-contact-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div> 
        </div>
        
    </div>
    <!-- End chat-message-list -->
</div>
<!-- Start chats content --><?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/tabpane-chats.blade.php ENDPATH**/ ?>