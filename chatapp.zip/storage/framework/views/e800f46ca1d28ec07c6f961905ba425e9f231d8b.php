<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('layouts.title-meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
     <!-- Begin page -->
     <div class="layout-wrapper d-lg-flex">
         <!-- Start left sidebar-menu -->
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- end left sidebar-menu -->

        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- END layout-wrapper -->
<!-- JAVASCRIPT -->
<?php echo $__env->make('layouts.vendor-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/master.blade.php ENDPATH**/ ?>