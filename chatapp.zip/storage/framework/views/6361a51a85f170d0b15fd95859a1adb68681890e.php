<?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="p-3 font-weight-bold text-primary text-uppercase"><?php echo e($user); ?></div>
    <ul class="list-unstyled contact-list">
        <?php $__currentLoopData = $key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="user" id="<?php echo e($contact->id); ?>">
                <div class="media align-items-center">
                    <div class="media-body">
                        <h5 class="font-size-14 m-0 chat-user-click" user-id="<?php echo e($contact->id); ?>">
                            <?php echo e($contact->name); ?></h5>
                    </div>
                    <div class="dropdown">
                        <a href="#" class="text-muted dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <i class="ri-more-2-fill"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right">
                            <a class="dropdown-item" href="#"><?php echo e(__('Share')); ?> <i
                                    class="ri-share-line float-right text-muted"></i></a>
                            <a class="dropdown-item" href="#"><?php echo e(__('Block')); ?> <i
                                    class="ri-forbid-line float-right text-muted"></i></a>
                            <a class="dropdown-item" href="<?php echo e(route('contact.destroy', $contact->id)); ?>"
                                id="deleteContact" type="submit" data-id="<?php echo e($contact->id); ?>"><?php echo e(__('Remove')); ?> <i
                                    class="ri-delete-bin-line float-right text-muted"></i></a>
                        </div>
                    </div>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/tabpane-contact-list.blade.php ENDPATH**/ ?>