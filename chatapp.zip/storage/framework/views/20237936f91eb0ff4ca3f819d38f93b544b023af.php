<!-- Start chat-group-list -->
<ul class="list-unstyled chat-list">
    <?php $__currentLoopData = $groupdata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="group" group-id="<?php echo e($group->id); ?>" id="group-<?php echo e($group->id); ?>">
            <a href="#">
                <div class="media align-items-center">
                    <div class="chat-user-img mr-3">
                        <div class="avatar-xs">
                            <span class="avatar-title rounded-circle bg-soft-primary text-primary text-uppercase">
                                <?php echo e(substr($group->group_name, 0, 1)); ?>

                            </span>
                        </div>
                    </div>
                    <div class="media-body overflow-hidden">
                        <h5 class="text-truncate font-size-14 mb-0">#<?php echo e($group->group_name); ?>

                            <?php if($group->users->is_read != 0): ?>
                                <span class="group-unread badge badge-soft-danger badge-pill float-right">+<?php echo e($group->users->is_read); ?></span>
                            <?php endif; ?>
                        </h5>
                    </div>
                </div>
            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<!-- End chat-group-list -->
<?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/chat-group-list.blade.php ENDPATH**/ ?>