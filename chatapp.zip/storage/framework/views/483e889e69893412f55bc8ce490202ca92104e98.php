<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li class="<?php echo e($message->from_user == Auth::id() ? 'right' : 'left'); ?>" id="msg-<?php echo e($message->id); ?>">
        <div class="conversation-list">
            <div class="chat-avatar">
                <?php if($message->from_user == Auth::id()): ?>
                    <img src="<?php echo e(Auth::user()->avatar); ?>" alt="" class="imgavatar">
                <?php else: ?>
                    <img src="<?php echo e($chatUser->avatar); ?>" alt="">
                <?php endif; ?>
            </div>

            <div class="user-chat-content">
                <div class="ctext-wrap">
                    <div class="ctext-wrap-content">
                        <?php if($message->file): ?>
                            <?php if(strtolower(pathinfo($message->file, PATHINFO_EXTENSION)) == 'jpg' || strtolower(pathinfo($message->file, PATHINFO_EXTENSION)) == 'png' || strtolower(pathinfo($message->file, PATHINFO_EXTENSION)) == 'gif'): ?>
                                <ul class="list-inline message-img  mb-0">
                                    <li class="list-inline-item message-img-list">
                                        <div>
                                            <a class="popup-img d-inline-block m-1" href="<?php echo e(asset($message->file)); ?>" title="<?php echo e(__("Project 1")); ?>">
                                                <img src="<?php echo e(asset($message->file)); ?>" alt="" class="rounded border">
                                            </a>
                                        </div>
                                        <div class="message-img-link">
                                            <ul class="list-inline mb-0">
                                                <li class="list-inline-item">
                                                    <a href="<?php echo e(asset($message->file)); ?>" download="">
                                                        <i class="ri-download-2-line"></i>
                                                    </a>
                                                </li>
                                                <li class="list-inline-item dropdown">
                                                    <a class="dropdown-toggle" href="<?php echo e($message->file); ?>" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="ri-more-fill"></i>
                                                    </a>
                                                    <div class="dropdown-menu">
                                                        <a class="dropdown-item" href="#"><?php echo e(__("Copy")); ?> <i class="ri-file-copy-line float-right text-muted"></i></a>
                                                        <a class="dropdown-item" href="#"><?php echo e(__("Save")); ?> <i class="ri-save-line float-right text-muted"></i></a>
                                                        <a class="dropdown-item" href="#"><?php echo e(__("Forward")); ?> <i class="ri-chat-forward-line float-right text-muted"></i></a>
                                                        <a class="dropdown-item deleteMessage" href="javascript:void(0)" msg-id="<?php echo e($message->id); ?>"><?php echo e(__("Delete")); ?> <i class="ri-delete-bin-line float-right text-muted"></i></a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                            <?php else: ?>
                                <div class="card p-2 mb-2">
                                    <div class="media align-items-center">
                                        <div class="avatar-sm mr-3">
                                            <div class="avatar-title bg-soft-primary text-primary rounded font-size-20">
                                                <i class="ri-file-text-fill"></i>
                                            </div>
                                        </div>
                                        <div class="media-body">
                                            <div class="text-left">
                                                <h5 class="font-size-14 mb-1"><?php echo e($message->message); ?></h5>
                                                <p class="text-muted font-size-13 mb-0">
                                                    <?php echo App\Http\Controllers\HomeController::bytesToHuman(File::size(public_path($message->file))); ?>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="ml-4">
                                            <ul class="list-inline mb-0 font-size-20">
                                                <li class="list-inline-item">
                                                    <a href="<?php echo e($message->file); ?>" class="text-muted">
                                                        <i class="ri-download-2-line"></i>
                                                    </a>
                                                </li>
                                                <li class="list-inline-item dropdown">
                                                    <a class="dropdown-toggle text-muted" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                                        <i class="ri-more-fill"></i>
                                                    </a>
                                                    <div class="dropdown-menu dropdown-menu-right" style="">
                                                        <a class="dropdown-item" href="#"><?php echo e(__("Share")); ?> <i class="ri-share-line float-right text-muted"></i></a>
                                                        <a class="dropdown-item deleteMessage" href="javascript:void(0)" msg-id="<?php echo e($message->id); ?>"><?php echo e(__("Delete")); ?> <i class="ri-delete-bin-line float-right text-muted"></i></a>
                                                    </div>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <p class="mb-0" id="aaa">
                                <?php echo e($message->message); ?>

                            </p>
                        <?php endif; ?>
                        <p class="chat-time mb-0">
                            <i class="ri-time-line align-middle"></i> 
                            <span class="align-middle"><?php echo e(date('d M y, h:i a', strtotime($message->created_at))); ?></span>
                        </p>
                    </div>
                    <div class="dropdown align-self-start">
                        <a class="dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true"
                            aria-expanded="false">
                            <i class="ri-more-2-fill"></i>
                        </a>
                        <div class="dropdown-menu">
                            <a class="dropdown-item copyTextToClipboard" data-text="<?php echo e($message->message); ?>"><?php echo e(__("Copy")); ?> <i class="ri-file-copy-line float-right text-muted"></i></a>
                            <a class="dropdown-item" href="#"><?php echo e(__("Save")); ?> <i class="ri-save-line float-right text-muted"></i></a>
                            <a class="dropdown-item" href="#"><?php echo e(__("Forward")); ?> <i class="ri-chat-forward-line float-right text-muted"></i></a>
                            <a class="dropdown-item deleteMessage" href="javascript:void(0)" msg-id="<?php echo e($message->id); ?>"><?php echo e(__("Delete")); ?> <i class="ri-delete-bin-line float-right text-muted"></i></a>
                        </div>
                    </div>
                </div>
                <?php if($message->from_user == Auth::id()): ?>
                    <div class="conversation-name profile-newname"><?php echo e(Auth::user()->name); ?></div>
                <?php else: ?>
                    <div class="conversation-name"><?php echo e($chatUser->name); ?></div>
                <?php endif; ?>

            </div>
        </div>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/message-conversation.blade.php ENDPATH**/ ?>