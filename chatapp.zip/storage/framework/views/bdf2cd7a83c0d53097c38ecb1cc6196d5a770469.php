<?php $__env->startSection('title'); ?><?php echo e(__("Login")); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
<body>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="account-pages my-5 pt-sm-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6 col-xl-5">
                <div class="text-center mb-4">
                    <a href="<?php echo e(url('/')); ?>" class="auth-logo mb-5 d-block">
                        <img src="<?php echo e(URL::asset('assets/images/logo-dark.png')); ?>" alt="" height="30" class="logo logo-dark">
                        <img src="<?php echo e(URL::asset('/assets/images/logo-light.png')); ?>" alt="" height="30" class="logo logo-light">
                    </a>
                    <h4><?php echo e(__("Sign in")); ?></h4>
                    <p class="text-muted mb-4"><?php echo e(__("Sign in to continue to chatapp.")); ?></p>
                </div>

                <div class="card">
                    <div class="card-body p-4">
                        <div class="p-3">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                
                                <div class="form-group">
                                    <label><?php echo e(__("Email")); ?></label>
                                    <div class="input-group mb-3 bg-soft-light input-group-lg rounded-lg">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text border-light text-muted">
                                                <i class="ri-user-2-line"></i>
                                            </span>
                                        </div>
                                        <input id="email" type="email" class="form-control bg-soft-light border-light <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email', 'admin@test.com')); ?>" required autocomplete="email" autofocus placeholder="<?php echo e(__("Enter Email")); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="form-group mb-4">
                                    <div class="float-right">
                                        <?php if(Route::has('password.request')): ?>
                                            <a href="<?php echo e(route('password.request')); ?>" class="text-muted font-size-13"><?php echo e(__('Forgot Password?')); ?></a>
                                        <?php endif; ?>
                                    </div>
                                    <label><?php echo e(__("Password")); ?></label>
                                    <div class="input-group mb-3 bg-soft-light input-group-lg rounded-lg">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text border-light text-muted">
                                                <i class="ri-lock-2-line"></i>
                                            </span>
                                        </div>
                                        <input id="password" type="password" class="form-control bg-soft-light border-light <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" value="password" required autocomplete="current-password" placeholder="<?php echo e(__("Enter Password")); ?>">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="custom-control custom-checkbox mb-4">
                                    <input class="custom-control-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <label class="custom-control-label" for="remember"><?php echo e(__('Remember Me')); ?></label>
                                </div>

                                <div>
                                    <button class="btn btn-primary btn-block waves-effect waves-light" type="submit"><?php echo e(__("Sign in")); ?></button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>

                <div class="mt-5 text-center">
                    <p><?php echo e(__("Don't have an account ?")); ?><a href="<?php echo e(url('register')); ?>" class="font-weight-medium text-primary"> <?php echo e(__("Signup now")); ?> </a> </p>
                    <p><?php echo e(__("© 2020 chatapp.")); ?></p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master-without-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\chatapp\resources\views/auth/login.blade.php ENDPATH**/ ?>