

<?php $__env->startSection('title'); ?> <?php echo e(__("Chat")); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- magnific-popup css -->
    <link href="<?php echo e(URL::asset('assets/libs/magnific-popup/magnific-popup.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- owl.carousel css -->
    <link href="<?php echo e(URL::asset('assets/libs/owl.carousel/owl.carousel.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start User chat -->
    <!-- start chat-leftsidebar -->
    <div class="chat-leftsidebar mr-lg-1">
        <div class="tab-content">
            <!-- Start Profile tab-pane -->
            <div class="tab-pane" id="pills-user" role="tabpanel" aria-labelledby="pills-user-tab">
                <?php echo $__env->make('layouts.tabpane-profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- End Profile tab-pane -->

            <!-- Start chats tab-pane -->
            <div class="tab-pane fade show active" id="pills-chat" role="tabpanel" aria-labelledby="pills-chat-tab">
                <?php echo $__env->make('layouts.tabpane-chats', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- End chats tab-pane -->

            <!-- Start groups tab-pane -->
            <div class="tab-pane" id="pills-groups" role="tabpanel" aria-labelledby="pills-groups-tab">
                <?php echo $__env->make('layouts.tabpane-groups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- End groups tab-pane -->

            <!-- Start contacts tab-pane -->
            <div class="tab-pane" id="pills-contacts" role="tabpanel" aria-labelledby="pills-contacts-tab">
                <?php echo $__env->make('layouts.tabpane-contacts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- End contacts tab-pane -->

            <!-- Start settings tab-pane -->
            <div class="tab-pane" id="pills-setting" role="tabpanel" aria-labelledby="pills-setting-tab">
                <?php echo $__env->make('layouts.tabpane-settings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <!-- End settings tab-pane -->
        </div>
        <!-- end tab content -->

    </div>
    <!-- end chat-leftsidebar -->
    <div class="user-chat w-100">
        <div class="d-lg-flex">
            <!-- start chat conversation section -->
            <div class="w-100">
                <div id="messages">
                </div>
                <div id="group-messages">
                </div>
            </div>
            <!-- start User profile detail sidebar -->
            <div id="userprofiledetail">
            </div>
            <div id="groupprofiledetail">
            </div>
            <!-- end User profile detail sidebar -->
        </div>
    </div>
    <!-- End User chat -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\chatapp\resources\views//index.blade.php ENDPATH**/ ?>