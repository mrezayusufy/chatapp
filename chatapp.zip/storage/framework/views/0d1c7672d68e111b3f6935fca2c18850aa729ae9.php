<!-- Start Groups content -->
<div>
    <div class="p-4">
        <div class="user-chat-nav float-right">
            <div data-toggle="tooltip" data-placement="bottom" title="<?php echo e(__('Create group')); ?>">
                <!-- Button trigger modal -->
                <button type="button" class="btn btn-link text-decoration-none text-muted font-size-18 py-0"
                    data-toggle="modal" data-target="#addgroup-exampleModal">
                    <i class="ri-group-line mr-1"></i>
                </button>
            </div>
        </div>

        <h4 class="mb-4"><?php echo e(__('Groups')); ?></h4>

        <!-- Start add group Modal -->
        <div class="modal fade" id="addgroup-exampleModal" tabindex="-1" role="dialog"
            aria-labelledby="addgroup-exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title font-size-16" id="addgroup-exampleModalLabel">
                            <?php echo e(__('Create a New Group.')); ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body p-4">
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="form-group mb-4">
                                <label for="addgroup_name-input"><?php echo e(__('Group Name')); ?></label>
                                <input type="text" class="form-control" placeholder="<?php echo e(__('Enter Group Name')); ?>"
                                    name="group_name" id="group_name">
                            </div>
                            <div class="form-group mb-4">
                                <label><?php echo e(__('Group Members')); ?></label>
                                <div class="mb-3">
                                    <button class="btn btn-light btn-sm" type="button" data-toggle="collapse"
                                        data-target="#groupmembercollapse" aria-expanded="false"
                                        aria-controls="groupmembercollapse">
                                        <?php echo e(__('Select Members')); ?>

                                    </button>
                                </div>

                                <div class="collapse" id="groupmembercollapse">
                                    <div class="card border">
                                        <div class="card-header">
                                            <h5 class="font-size-15 mb-0"><?php echo e(__('Contacts')); ?></h5>
                                        </div>
                                        <div class="card-body p-2">
                                            <div data-simplebar style="max-height: 150px;">
                                                <div>
                                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user => $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="p-3 font-weight-bold text-primary text-uppercase">
                                                            <?php echo e($user); ?>

                                                        </div>
                                                        <ul class="list-unstyled contact-list">
                                                            <?php $__currentLoopData = $key; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <li id="<?php echo e($contact->id); ?>">
                                                                    <div class="custom-control custom-checkbox">
                                                                        <input type="checkbox"
                                                                            class="custom-control-input batchCheckbox"
                                                                            id="contact-<?php echo e($contact->id); ?>"
                                                                            name="checkboxusers[]"
                                                                            value="<?php echo e($contact->id); ?>">
                                                                        <label class="custom-control-label"
                                                                            for="contact-<?php echo e($contact->id); ?>"><?php echo e($contact->name); ?></label>
                                                                    </div>
                                                                </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </ul>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </div>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="addgroupdescription-input"><?php echo e(__('Description')); ?></label>
                                <textarea class="form-control" id="description" rows="3"
                                    placeholder="<?php echo e(__('Enter Description')); ?>" name="description"></textarea>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-link" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
                        <button type="button" class="btn btn-primary create-group"
                            data-dismiss="modal"><?php echo e(__('Create')); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <!-- End add group Modal -->

        <div class="search-box chat-search-box">
            <div class="input-group bg-light  input-group-lg rounded-lg">
                <div class="input-group-prepend">
                    <button class="btn btn-link text-decoration-none text-muted pr-1" type="button">
                        <i class="ri-search-line search-icon font-size-18"></i>
                    </button>
                </div>
                <input type="text" class="form-control bg-light" placeholder="<?php echo e(__('Search groups')); ?>..."
                    id="groupsearch">
            </div>
        </div>
        <!-- end search-box -->
    </div>
    <div class="p-4 chat-message-list chat-group-list" data-simplebar>
        <div id="chat-group-list">
            <?php echo $__env->make('layouts.chat-group-list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
</div>
<!-- End Groups content -->
<?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/tabpane-groups.blade.php ENDPATH**/ ?>