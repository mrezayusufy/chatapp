<ul class="list-unstyled chat-list chat-user-list">
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="user" data-id="<?php echo e($user->id); ?>" id="user-<?php echo e($user->id); ?>" user-id="<?php echo e($user->id); ?>">
            <a href="#">
                <div class="media">
                    <?php if(Cache::has('is_online' . $user->id)): ?>
                        <div class="chat-user-img online align-self-center mr-3">
                            <img src="<?php echo e($user->avatar); ?>" class="rounded-circle avatar-xs" alt="">
                            <span class="user-status"></span>
                        </div>
                    <?php else: ?>
                        <div class="chat-user-img away align-self-center mr-3">
                            <img src="<?php echo e($user->avatar); ?>" class="rounded-circle avatar-xs" alt="">
                            <span class="user-status"></span>
                        </div>
                    <?php endif; ?>

                    <div class="media-body overflow-hidden">
                        <h5 class="text-truncate font-size-15 mb-1"><?php echo e($user->name); ?></h5>

                        <?php if($user->file): ?>
                            <?php if(strtolower(pathinfo($user->file, PATHINFO_EXTENSION)) == 'jpg' || strtolower(pathinfo($user->file, PATHINFO_EXTENSION)) == 'png' || strtolower(pathinfo($user->file, PATHINFO_EXTENSION)) == 'gif'): ?>
                                <p class="chat-user-message text-truncate mb-0"><i class="ri-image-fill align-middle mr-1"></i> <?php echo e($user->message); ?></p>
                            <?php else: ?>
                                <p class="chat-user-message text-truncate mb-0"><i class="ri-file-text-fill align-middle mr-1"></i> <?php echo e($user->message); ?></p>
                            <?php endif; ?>

                        <?php else: ?>
                            <p class="chat-user-message text-truncate mb-0"><?php echo e($user->message); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php if(date('Y-m-d') == date('Y-m-d', strtotime($user->created_at))): ?>
                        <div class="font-size-11"><?php echo e(date('h:i a', strtotime($user->created_at))); ?></div>
                    <?php else: ?>
                        <div class="font-size-11"><?php echo e(date('d/m', strtotime($user->created_at))); ?></div>
                    <?php endif; ?>
                    <?php if($user->unread): ?>
                        <div class="unread-message">
                            <span class="badge badge-soft-danger badge-pill pending"><?php echo e($user->unread); ?></span>
                        </div>
                    <?php endif; ?>
                </div>
            </a>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>
<?php /**PATH C:\laragon\www\chatapp\resources\views/layouts/tabpane-recent-contact-list.blade.php ENDPATH**/ ?>